﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SKGL;

namespace KeysGenerator
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void FormMain_Load(object sender, EventArgs e)
        {
            this.cmbDays.SelectedIndex = 2;
            toolTip.AutoPopDelay = 10000;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Checkbox_ShowPassword_OnChange(object sender, EventArgs e)
        {
            if(this.Checkbox_ShowPassword.Checked == true)
            {
                this.txtPassword.UseSystemPasswordChar = false;
            }
            else
            {
                this.txtPassword.UseSystemPasswordChar = true;
            }
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            // Generate The New Key 
            Generate Gnrt = new Generate();
            Gnrt.secretPhase = this.txtPassword.Text;
            this.txtNewKey.Text = Gnrt.doKey(Convert.ToInt32(this.cmbDays.Text));

            // Print The Info of new Key 
            Validate Vld = new Validate();
            Vld.secretPhase = this.txtPassword.Text;
            Vld.Key = this.txtNewKey.Text;
            this.txtInfo.Text = "Create Date :"+Vld.CreationDate+"\r\n" + "Expire Date:" +Vld.ExpireDate+"\r\n"+"Days Left:"+Vld.DaysLeft+"";
        }

        private void lnkCopy_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Clipboard.SetText(this.txtNewKey.Text);
            MessageBox.Show("The key has been copied into the Clipboard", "Keys Copy", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void lnkOldKeyInfo_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if(this.txtPassword.Text != string.Empty && this.txtNewKey.Text != string.Empty)
            {
                // Print The Info of new Key 
                Validate Vld = new Validate();
                Vld.secretPhase = this.txtPassword.Text;
                Vld.Key = this.txtNewKey.Text;
                this.txtInfo.Text = "Create Date :" + Vld.CreationDate + "\r\n" + "Expire Date:" + Vld.ExpireDate + "\r\n" + "Days Left:" + Vld.DaysLeft + "";
            }
        }
    }
}
