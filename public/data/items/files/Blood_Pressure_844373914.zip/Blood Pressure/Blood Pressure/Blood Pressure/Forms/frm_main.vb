﻿Public Class frm_main

    Dim DS As New DataSet()
    Public show_state As String = ""

    'Procedure to Repare StartUP
    Private Sub RepareStartUp()
        ' Show User Full name
        Me.lbl_username.Text = My.Settings.username
    End Sub

    Private Sub btn_menu_toogle_Click(sender As Object, e As EventArgs) Handles btn_menu_toogle.Click
        If Me.pnl_menu.Width = 0 Then
            Me.pnl_menu.Width = 240
        Else
            Me.pnl_menu.Width = 0
        End If
    End Sub

    Private Sub btn_close_Click(sender As Object, e As EventArgs) Handles btn_close.Click
        Application.Exit()
    End Sub

    Private Sub frm_main_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.RepareStartUp()
        DS.ReadXml("Data.xml")
    End Sub

    Private Sub btn_new_read_Click(sender As Object, e As EventArgs) Handles btn_new_read.Click
        If Me.show_state = "" Then
            Dim f As New frm_new_read()
            f.TopLevel = False
            Me.pnl_show.Controls.Add(f)
            f.Dock = DockStyle.Fill
            Me.lbl_start.Hide()
            show_state = "newread"
            f.Show()
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Me.lbl_time.Text = Now.ToLongTimeString()
    End Sub

    Private Sub BunifuThinButton25_Click(sender As Object, e As EventArgs) Handles BunifuThinButton25.Click
        Dim f As New frm_user_info_edit()
        f.ShowDialog()
    End Sub

    Private Sub BunifuThinButton22_Click(sender As Object, e As EventArgs) Handles BunifuThinButton22.Click
        If Me.show_state = "" Then
            Dim f As New frm_old_read()
            f.TopLevel = False
            Me.pnl_show.Controls.Add(f)
            f.Dock = DockStyle.Fill
            Me.lbl_start.Hide()
            show_state = "oldread"
            f.Show()
        End If
    End Sub


    Private Sub BunifuThinButton21_Click(sender As Object, e As EventArgs) Handles BunifuThinButton21.Click
        If Me.show_state = "" Then
            Dim f As New frm_maintain_my_plusser()
            f.TopLevel = False
            Me.pnl_show.Controls.Add(f)
            f.Dock = DockStyle.Fill
            Me.lbl_start.Hide()
            show_state = "maintain"
            f.Show()
        End If
    End Sub

    Private Sub BunifuThinButton23_Click(sender As Object, e As EventArgs) Handles BunifuThinButton23.Click
        If Me.show_state = "" Then
            Dim f As New frm_why_use_this()
            f.TopLevel = False
            Me.pnl_show.Controls.Add(f)
            f.Dock = DockStyle.Fill
            Me.lbl_start.Hide()
            show_state = "whyusethis"
            f.Show()
        End If
    End Sub
End Class