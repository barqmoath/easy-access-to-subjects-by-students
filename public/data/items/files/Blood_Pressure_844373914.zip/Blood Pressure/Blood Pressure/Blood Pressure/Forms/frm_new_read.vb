﻿Public Class frm_new_read

    Dim DS As New DataSet()


    Private Sub btn_close_Click(sender As Object, e As EventArgs) Handles btn_close.Click
        Me.Close()
        frm_main.lbl_start.Show()
        frm_main.show_state = ""
    End Sub

    Private Sub ClacPressure(bp1 As Double, bp2 As Double)

        If bp1 < 120 And bp1 >= 60 Or bp2 < 80 And bp2 >= 40 Then
            lbl_Bp_Result.Text = "ضغط الدم لديك مثالي لاحاجه للقلق"
            CPB.ProgressColor = Color.FromArgb(106, 176, 76)
            CPB.Value = 98
        ElseIf bp1 = 120 And bp2 = 80 Then
            lbl_Bp_Result.Text = "ضغط الدم لديك مثالي لاحاجه للقلق"
            CPB.ProgressColor = Color.FromArgb(106, 176, 76)
            CPB.Value = 98
        Else
            If bp1 > 120 And bp1 <= 139 And bp2 > 80 And bp2 <= 89 Then
                lbl_Bp_Result.Text = "ضغط الدم لديك جيد .. لاكن حاول مراقبه طعامك لأنك مؤهل للاصابه بارتفاع ضغط الدم"
                CPB.ProgressColor = Color.FromArgb(249, 202, 36)
                CPB.Value = 98
            ElseIf bp1 >= 140 And bp1 <= 159 And bp2 >= 90 And bp2 <= 99 Then
                lbl_Bp_Result.Text = "ضغط الدم لدبك مرتفع حاول زياره الطبيب في اقرب فرصه ممكنه"
                CPB.ProgressColor = Color.FromArgb(240, 147, 43)
                CPB.Value = 98
            ElseIf bp1 >= 160 And bp2 >= 100 Then
                lbl_Bp_Result.Text = "انت في خطر شديد توجه الى المشفى حالا لان ضغط الدم لديك مرتفع جدا عن الحد الطبيعي"
                lbl_Bp_Result.ForeColor = Color.FromArgb(235, 77, 75)
                CPB.ProgressColor = Color.FromArgb(235, 77, 75)
                CPB.Value = 98
            Else
                lbl_Bp_Result.Text = "معلومات غير متوفــره ):"
            End If
        End If
    End Sub

    Private Sub CalcPulse(pulse As Double)
        Dim age As Double = Convert.ToDouble(My.Settings.user_age)

        If age >= 1 And age <= 2 Then
            If pulse >= 80 And pulse <= 130 Then
                lbl_pulse_result.Text = "ضربات القلب بحاله مثاليه"
                lbl_pulse_result.ForeColor = Color.FromArgb(106, 176, 76)
            Else
                lbl_pulse_result.Text = "ضربات القلب في حاله حرجه بالنسبه لشخص في وضع الراحه"
                lbl_pulse_result.ForeColor = Color.Red
            End If

        ElseIf age >= 3 And age <= 4 Then
            If pulse >= 80 And pulse <= 120 Then
                lbl_pulse_result.Text = "ضربات القلب بحاله مثاليه"
                lbl_pulse_result.ForeColor = Color.FromArgb(106, 176, 76)
            Else
                lbl_pulse_result.Text = "ضربات القلب في حاله حرجه بالنسبه لشخص في وضع الراحه"
                lbl_pulse_result.ForeColor = Color.Red
            End If

        ElseIf age >= 5 And age <= 6 Then
            If pulse >= 75 And pulse <= 115 Then
                lbl_pulse_result.Text = "ضربات القلب بحاله مثاليه"
                lbl_pulse_result.ForeColor = Color.FromArgb(106, 176, 76)
            Else
                lbl_pulse_result.Text = "ضربات القلب في حاله حرجه بالنسبه لشخص في وضع الراحه"
                lbl_pulse_result.ForeColor = Color.Red
            End If

        ElseIf age >= 7 And age <= 9 Then
            If pulse >= 70 And pulse <= 110 Then
                lbl_pulse_result.Text = "ضربات القلب بحاله مثاليه"
                lbl_pulse_result.ForeColor = Color.FromArgb(106, 176, 76)
            Else
                lbl_pulse_result.Text = "ضربات القلب في حاله حرجه بالنسبه لشخص في وضع الراحه"
                lbl_pulse_result.ForeColor = Color.Red
            End If

        ElseIf age >= 10 Then
            If pulse >= 60 And pulse <= 100 Then
                lbl_pulse_result.Text = "ضربات القلب بحاله مثاليه"
                lbl_pulse_result.ForeColor = Color.FromArgb(106, 176, 76)
            Else
                lbl_pulse_result.Text = "ضربات القلب في حاله حرجه بالنسبه لشخص في وضع الراحه"
                lbl_pulse_result.ForeColor = Color.Red
            End If
        End If
    End Sub

    Private Sub btn_start_Click(sender As Object, e As EventArgs) Handles btn_start.Click
        Me.ClacPressure(Convert.ToDouble(Me.txt_bp1.Text), Convert.ToDouble(Me.txt_bp2.Text))
        Me.CalcPulse(Convert.ToDouble(Me.txt_pulse.Text))
    End Sub

    Private Sub SavePressure()
        Dim rand As New Random()
        Dim id As Integer = rand.Next(1234, 123456789)
        Dim row As DataRow = DS.Tables(0).NewRow
        row(0) = id
        row(1) = DateTime.Now
        row(2) = txt_bp1.Text & "/" & txt_bp2.Text
        row(3) = lbl_Bp_Result.Text
        row(4) = txt_pulse.Text
        DS.Tables(0).Rows.Add(row)
        DS.WriteXml("Data.xml")
        lbl_save_state.Text = "SAVED"
        lbl_save_state.ForeColor = Color.FromArgb(106, 176, 76)
    End Sub


    Private Sub btn_save_Click(sender As Object, e As EventArgs) Handles btn_save.Click
        If MessageBox.Show("Do You Want Save This", "Save Continu", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes Then
            SavePressure()
        End If
    End Sub

    Private Sub txt_bp1_Enter(sender As Object, e As EventArgs) Handles txt_bp1.Enter
        Me.CPB.Value = 25
        Me.CPB.ProgressColor = Color.FromArgb(214, 48, 49)
        lbl_Bp_Result.Text = "Input Data and Click Start"
        lbl_pulse_result.Text = ""
        lbl_Bp_Result.ForeColor = Color.Black
    End Sub

    Private Sub txt_bp2_Enter(sender As Object, e As EventArgs) Handles txt_bp2.Enter
        Me.CPB.Value = 25
        Me.CPB.ProgressColor = Color.FromArgb(214, 48, 49)
        lbl_Bp_Result.Text = "Input Data and Click Start"
        lbl_pulse_result.Text = ""
        lbl_Bp_Result.ForeColor = Color.Black
    End Sub

    Private Sub txt_pulse_Enter(sender As Object, e As EventArgs) Handles txt_pulse.Enter
        Me.CPB.Value = 25
        Me.CPB.ProgressColor = Color.FromArgb(214, 48, 49)
        lbl_Bp_Result.Text = "Input Data and Click Start"
        lbl_pulse_result.Text = ""
        lbl_Bp_Result.ForeColor = Color.Black
    End Sub

    Private Sub frm_new_read_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DS.ReadXml("Data.xml")
    End Sub
End Class