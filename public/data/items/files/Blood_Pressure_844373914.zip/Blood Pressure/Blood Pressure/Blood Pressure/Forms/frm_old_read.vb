﻿Public Class frm_old_read

    Dim DS As New DataSet()

    Private Sub btn_close_Click(sender As Object, e As EventArgs) Handles btn_close.Click
        Me.Close()
        frm_main.lbl_start.Show()
        frm_main.show_state = ""
    End Sub

    Private Sub frm_old_read_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'DS.Tables(0).Rows.Clear()
        DS.ReadXml("Data.xml")
        Me.DGV_READ.DataSource = DS.Tables(0)
        Me.DGV_READ.DefaultCellStyle.SelectionBackColor = Color.FromArgb(214, 48, 49)
        Me.DGV_READ.DefaultCellStyle.SelectionForeColor = Color.White
        Me.DGV_READ.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Me.DGV_READ.RowTemplate.Height = 30
        Me.DGV_READ.Columns(0).Visible = False
        Me.DGV_READ.Columns(1).HeaderText = "Date"
        Me.DGV_READ.Columns(2).HeaderText = "Content"
        Me.DGV_READ.Columns(3).HeaderText = "State"
        Me.DGV_READ.Columns(4).HeaderText = "Pluser"

    End Sub

    Private Sub btn_delete_Click(sender As Object, e As EventArgs) Handles btn_delete.Click
        If Me.DGV_READ.CurrentRow.Cells(0).Value = 1 Then
            MessageBox.Show("Can not Delete root")
        Else
            If (MessageBox.Show("Are you need Delete This ?", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes) Then
                For i As Integer = 0 To DS.Tables(0).Rows.Count - 1
                    If (Me.DGV_READ.CurrentRow.Cells(0).Value = DS.Tables(0).Rows(i)(0).ToString()) Then
                        DS.Tables(0).Rows(i).Delete()
                        DS.WriteXml("Data.xml")
                        MsgBox("Deleted Successfuly")
                    End If
                Next
            End If
        End If
    End Sub

    Private Sub btn_refresh_Click(sender As Object, e As EventArgs) Handles btn_refresh.Click
        DS.Tables(0).Rows.Clear()
        DS.ReadXml("Data.xml")
        Me.DGV_READ.DataSource = DS.Tables(0)
        Me.DGV_READ.DefaultCellStyle.SelectionBackColor = Color.FromArgb(214, 48, 49)
        Me.DGV_READ.DefaultCellStyle.SelectionForeColor = Color.White
        Me.DGV_READ.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter
        Me.DGV_READ.RowTemplate.Height = 30
        Me.DGV_READ.Columns(0).Visible = False
        Me.DGV_READ.Columns(1).HeaderText = "Date"
        Me.DGV_READ.Columns(2).HeaderText = "Content"
        Me.DGV_READ.Columns(3).HeaderText = "State"
        Me.DGV_READ.Columns(4).HeaderText = "Pluser"

    End Sub



    Private Sub MaterialFlatButton1_Click(sender As Object, e As EventArgs) Handles MaterialFlatButton1.Click
        Dim f As New frm_show_report()
        f.lbl_r_date.Text = Me.DGV_READ.CurrentRow.Cells(1).Value.ToString()
        f.lbl_bp1.Text = Me.DGV_READ.CurrentRow.Cells(2).Value.ToString()
        f.lbl_pulse.Text = Me.DGV_READ.CurrentRow.Cells(4).Value.ToString()
        f.lbl_state.Text = Me.DGV_READ.CurrentRow.Cells(3).Value.ToString()
        f.ShowDialog()
    End Sub

End Class