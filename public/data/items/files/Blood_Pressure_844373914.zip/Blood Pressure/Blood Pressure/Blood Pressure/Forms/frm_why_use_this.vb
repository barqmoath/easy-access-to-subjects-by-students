﻿Public Class frm_why_use_this
    Private Sub btn_close_Click(sender As Object, e As EventArgs) Handles btn_close.Click
        Me.Close()
        frm_main.lbl_start.Show()
        frm_main.show_state = ""
    End Sub
End Class