﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_new_read
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_new_read))
        Me.pnl_header = New System.Windows.Forms.Panel()
        Me.lbl_save_state = New System.Windows.Forms.Label()
        Me.btn_close = New Bunifu.Framework.UI.BunifuImageButton()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.btn_start = New MaterialSkin.Controls.MaterialFlatButton()
        Me.btn_save = New MaterialSkin.Controls.MaterialFlatButton()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.BunifuSeparator1 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.CPB = New CircularProgressBar.CircularProgressBar()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.lbl_Bp_Result = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.lbl_pulse_result = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txt_pulse = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txt_bp2 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_bp1 = New System.Windows.Forms.TextBox()
        Me.pnl_header.SuspendLayout()
        CType(Me.btn_close, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'pnl_header
        '
        Me.pnl_header.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.pnl_header.Controls.Add(Me.lbl_save_state)
        Me.pnl_header.Controls.Add(Me.btn_close)
        Me.pnl_header.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnl_header.Location = New System.Drawing.Point(0, 0)
        Me.pnl_header.Name = "pnl_header"
        Me.pnl_header.Size = New System.Drawing.Size(719, 30)
        Me.pnl_header.TabIndex = 1
        '
        'lbl_save_state
        '
        Me.lbl_save_state.Dock = System.Windows.Forms.DockStyle.Right
        Me.lbl_save_state.ForeColor = System.Drawing.Color.Black
        Me.lbl_save_state.Location = New System.Drawing.Point(623, 0)
        Me.lbl_save_state.Name = "lbl_save_state"
        Me.lbl_save_state.Size = New System.Drawing.Size(96, 30)
        Me.lbl_save_state.TabIndex = 5
        Me.lbl_save_state.Text = "NOT SAVED"
        Me.lbl_save_state.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_close
        '
        Me.btn_close.BackColor = System.Drawing.Color.Transparent
        Me.btn_close.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_close.Dock = System.Windows.Forms.DockStyle.Left
        Me.btn_close.Image = CType(resources.GetObject("btn_close.Image"), System.Drawing.Image)
        Me.btn_close.ImageActive = CType(resources.GetObject("btn_close.ImageActive"), System.Drawing.Image)
        Me.btn_close.Location = New System.Drawing.Point(0, 0)
        Me.btn_close.Name = "btn_close"
        Me.btn_close.Size = New System.Drawing.Size(30, 30)
        Me.btn_close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btn_close.TabIndex = 4
        Me.btn_close.TabStop = False
        Me.ToolTip1.SetToolTip(Me.btn_close, "Go Back")
        Me.btn_close.Zoom = 10
        '
        'btn_start
        '
        Me.btn_start.AutoSize = True
        Me.btn_start.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btn_start.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_start.Depth = 0
        Me.btn_start.Icon = CType(resources.GetObject("btn_start.Icon"), System.Drawing.Image)
        Me.btn_start.Location = New System.Drawing.Point(95, 6)
        Me.btn_start.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.btn_start.MouseState = MaterialSkin.MouseState.HOVER
        Me.btn_start.Name = "btn_start"
        Me.btn_start.Primary = False
        Me.btn_start.Size = New System.Drawing.Size(147, 36)
        Me.btn_start.TabIndex = 3
        Me.btn_start.Text = "Start Analys"
        Me.ToolTip1.SetToolTip(Me.btn_start, "Start Analys")
        Me.btn_start.UseVisualStyleBackColor = True
        '
        'btn_save
        '
        Me.btn_save.AutoSize = True
        Me.btn_save.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btn_save.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_save.Depth = 0
        Me.btn_save.Icon = CType(resources.GetObject("btn_save.Icon"), System.Drawing.Image)
        Me.btn_save.Location = New System.Drawing.Point(4, 6)
        Me.btn_save.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.btn_save.MouseState = MaterialSkin.MouseState.HOVER
        Me.btn_save.Name = "btn_save"
        Me.btn_save.Primary = False
        Me.btn_save.Size = New System.Drawing.Size(83, 36)
        Me.btn_save.TabIndex = 4
        Me.btn_save.Text = "Save"
        Me.ToolTip1.SetToolTip(Me.btn_save, "Save")
        Me.btn_save.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.BunifuSeparator1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 427)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(719, 58)
        Me.Panel1.TabIndex = 2
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.btn_save)
        Me.Panel2.Controls.Add(Me.btn_start)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel2.Location = New System.Drawing.Point(464, 10)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(255, 48)
        Me.Panel2.TabIndex = 5
        '
        'BunifuSeparator1
        '
        Me.BunifuSeparator1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuSeparator1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BunifuSeparator1.LineThickness = 1
        Me.BunifuSeparator1.Location = New System.Drawing.Point(0, 0)
        Me.BunifuSeparator1.Name = "BunifuSeparator1"
        Me.BunifuSeparator1.Size = New System.Drawing.Size(719, 10)
        Me.BunifuSeparator1.TabIndex = 3
        Me.BunifuSeparator1.Transparency = 255
        Me.BunifuSeparator1.Vertical = False
        '
        'CPB
        '
        Me.CPB.AnimationFunction = WinFormAnimation.KnownAnimationFunctions.SinusoidalEaseIn
        Me.CPB.AnimationSpeed = 500
        Me.CPB.BackColor = System.Drawing.Color.Transparent
        Me.CPB.Font = New System.Drawing.Font("Segoe UI", 14.0!)
        Me.CPB.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.CPB.InnerColor = System.Drawing.Color.White
        Me.CPB.InnerMargin = 2
        Me.CPB.InnerWidth = -1
        Me.CPB.Location = New System.Drawing.Point(31, 85)
        Me.CPB.MarqueeAnimationSpeed = 2000
        Me.CPB.Name = "CPB"
        Me.CPB.OuterColor = System.Drawing.Color.Gainsboro
        Me.CPB.OuterMargin = -25
        Me.CPB.OuterWidth = 25
        Me.CPB.ProgressColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.CPB.ProgressWidth = 20
        Me.CPB.SecondaryFont = New System.Drawing.Font("Tahoma", 36.0!)
        Me.CPB.Size = New System.Drawing.Size(305, 305)
        Me.CPB.StartAngle = 270
        Me.CPB.Style = System.Windows.Forms.ProgressBarStyle.Marquee
        Me.CPB.SubscriptColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(166, Byte), Integer), CType(CType(166, Byte), Integer))
        Me.CPB.SubscriptMargin = New System.Windows.Forms.Padding(10, -35, 0, 0)
        Me.CPB.SubscriptText = ""
        Me.CPB.SuperscriptColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(166, Byte), Integer), CType(CType(166, Byte), Integer))
        Me.CPB.SuperscriptMargin = New System.Windows.Forms.Padding(10, 35, 0, 0)
        Me.CPB.SuperscriptText = ""
        Me.CPB.TabIndex = 3
        Me.CPB.Text = "BLOOD PRESSURE ALERT"
        Me.CPB.TextMargin = New System.Windows.Forms.Padding(8, 8, 0, 0)
        Me.CPB.Value = 25
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.lbl_Bp_Result)
        Me.Panel3.Controls.Add(Me.CPB)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel3.Location = New System.Drawing.Point(338, 30)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(381, 397)
        Me.Panel3.TabIndex = 4
        '
        'lbl_Bp_Result
        '
        Me.lbl_Bp_Result.Dock = System.Windows.Forms.DockStyle.Top
        Me.lbl_Bp_Result.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.lbl_Bp_Result.Location = New System.Drawing.Point(0, 0)
        Me.lbl_Bp_Result.Name = "lbl_Bp_Result"
        Me.lbl_Bp_Result.Size = New System.Drawing.Size(381, 72)
        Me.lbl_Bp_Result.TabIndex = 4
        Me.lbl_Bp_Result.Text = "Input Data And Click Start "
        Me.lbl_Bp_Result.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.lbl_pulse_result)
        Me.Panel4.Controls.Add(Me.PictureBox1)
        Me.Panel4.Controls.Add(Me.GroupBox2)
        Me.Panel4.Controls.Add(Me.GroupBox1)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel4.Location = New System.Drawing.Point(0, 30)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(332, 397)
        Me.Panel4.TabIndex = 5
        '
        'lbl_pulse_result
        '
        Me.lbl_pulse_result.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.lbl_pulse_result.Location = New System.Drawing.Point(23, 127)
        Me.lbl_pulse_result.Name = "lbl_pulse_result"
        Me.lbl_pulse_result.Size = New System.Drawing.Size(300, 72)
        Me.lbl_pulse_result.TabIndex = 5
        Me.lbl_pulse_result.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(23, 202)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(300, 188)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.txt_pulse)
        Me.GroupBox2.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.GroupBox2.Location = New System.Drawing.Point(176, 23)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(147, 92)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "PULSE"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(86, 29)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(55, 20)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Minute"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(74, 29)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(15, 20)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "/"
        '
        'txt_pulse
        '
        Me.txt_pulse.Location = New System.Drawing.Point(16, 26)
        Me.txt_pulse.Name = "txt_pulse"
        Me.txt_pulse.Size = New System.Drawing.Size(55, 27)
        Me.txt_pulse.TabIndex = 0
        Me.txt_pulse.Text = "72"
        Me.txt_pulse.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txt_bp2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txt_bp1)
        Me.GroupBox1.Font = New System.Drawing.Font("Segoe UI", 11.0!)
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.GroupBox1.Location = New System.Drawing.Point(23, 23)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(147, 92)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "BLOOD PRESSURE"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(51, 62)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(46, 20)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "mmH"
        '
        'txt_bp2
        '
        Me.txt_bp2.Location = New System.Drawing.Point(89, 26)
        Me.txt_bp2.Name = "txt_bp2"
        Me.txt_bp2.Size = New System.Drawing.Size(46, 27)
        Me.txt_bp2.TabIndex = 2
        Me.txt_bp2.Text = "80"
        Me.txt_bp2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(68, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(15, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "/"
        '
        'txt_bp1
        '
        Me.txt_bp1.Location = New System.Drawing.Point(16, 26)
        Me.txt_bp1.Name = "txt_bp1"
        Me.txt_bp1.Size = New System.Drawing.Size(46, 27)
        Me.txt_bp1.TabIndex = 0
        Me.txt_bp1.Text = "120"
        Me.txt_bp1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'frm_new_read
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(719, 485)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.pnl_header)
        Me.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frm_new_read"
        Me.ShowIcon = False
        Me.Text = "frm_new_read"
        Me.pnl_header.ResumeLayout(False)
        CType(Me.btn_close, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pnl_header As Panel
    Friend WithEvents btn_close As Bunifu.Framework.UI.BunifuImageButton
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents btn_save As MaterialSkin.Controls.MaterialFlatButton
    Friend WithEvents btn_start As MaterialSkin.Controls.MaterialFlatButton
    Friend WithEvents BunifuSeparator1 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents CPB As CircularProgressBar.CircularProgressBar
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txt_pulse As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txt_bp2 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txt_bp1 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents lbl_Bp_Result As Label
    Friend WithEvents lbl_save_state As Label
    Friend WithEvents lbl_pulse_result As Label
    Friend WithEvents PictureBox1 As PictureBox
End Class
