﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_old_read
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_old_read))
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.MaterialFlatButton1 = New MaterialSkin.Controls.MaterialFlatButton()
        Me.btn_delete = New MaterialSkin.Controls.MaterialFlatButton()
        Me.BunifuSeparator1 = New Bunifu.Framework.UI.BunifuSeparator()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.btn_close = New Bunifu.Framework.UI.BunifuImageButton()
        Me.btn_refresh = New Bunifu.Framework.UI.BunifuImageButton()
        Me.pnl_header = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.DGV_READ = New System.Windows.Forms.DataGridView()
        Me.Panel2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.btn_close, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btn_refresh, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnl_header.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DGV_READ, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.MaterialFlatButton1)
        Me.Panel2.Controls.Add(Me.btn_delete)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel2.Location = New System.Drawing.Point(454, 10)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(265, 48)
        Me.Panel2.TabIndex = 5
        '
        'MaterialFlatButton1
        '
        Me.MaterialFlatButton1.AutoSize = True
        Me.MaterialFlatButton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.MaterialFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.MaterialFlatButton1.Depth = 0
        Me.MaterialFlatButton1.Icon = CType(resources.GetObject("MaterialFlatButton1.Icon"), System.Drawing.Image)
        Me.MaterialFlatButton1.Location = New System.Drawing.Point(4, 6)
        Me.MaterialFlatButton1.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.MaterialFlatButton1.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialFlatButton1.Name = "MaterialFlatButton1"
        Me.MaterialFlatButton1.Primary = False
        Me.MaterialFlatButton1.Size = New System.Drawing.Size(143, 36)
        Me.MaterialFlatButton1.TabIndex = 4
        Me.MaterialFlatButton1.Text = "Show Report"
        Me.ToolTip1.SetToolTip(Me.MaterialFlatButton1, "Show Report of Selected Read")
        Me.MaterialFlatButton1.UseVisualStyleBackColor = True
        '
        'btn_delete
        '
        Me.btn_delete.AutoSize = True
        Me.btn_delete.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.btn_delete.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_delete.Depth = 0
        Me.btn_delete.Icon = CType(resources.GetObject("btn_delete.Icon"), System.Drawing.Image)
        Me.btn_delete.Location = New System.Drawing.Point(155, 6)
        Me.btn_delete.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.btn_delete.MouseState = MaterialSkin.MouseState.HOVER
        Me.btn_delete.Name = "btn_delete"
        Me.btn_delete.Primary = False
        Me.btn_delete.Size = New System.Drawing.Size(97, 36)
        Me.btn_delete.TabIndex = 3
        Me.btn_delete.Text = "DELETE "
        Me.ToolTip1.SetToolTip(Me.btn_delete, "Delete Selected Item")
        Me.btn_delete.UseVisualStyleBackColor = True
        '
        'BunifuSeparator1
        '
        Me.BunifuSeparator1.BackColor = System.Drawing.Color.Transparent
        Me.BunifuSeparator1.Dock = System.Windows.Forms.DockStyle.Top
        Me.BunifuSeparator1.LineColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BunifuSeparator1.LineThickness = 1
        Me.BunifuSeparator1.Location = New System.Drawing.Point(0, 0)
        Me.BunifuSeparator1.Name = "BunifuSeparator1"
        Me.BunifuSeparator1.Size = New System.Drawing.Size(719, 10)
        Me.BunifuSeparator1.TabIndex = 3
        Me.BunifuSeparator1.Transparency = 255
        Me.BunifuSeparator1.Vertical = False
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.BunifuSeparator1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 427)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(719, 58)
        Me.Panel1.TabIndex = 7
        '
        'btn_close
        '
        Me.btn_close.BackColor = System.Drawing.Color.Transparent
        Me.btn_close.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_close.Dock = System.Windows.Forms.DockStyle.Left
        Me.btn_close.Image = CType(resources.GetObject("btn_close.Image"), System.Drawing.Image)
        Me.btn_close.ImageActive = CType(resources.GetObject("btn_close.ImageActive"), System.Drawing.Image)
        Me.btn_close.Location = New System.Drawing.Point(0, 0)
        Me.btn_close.Name = "btn_close"
        Me.btn_close.Size = New System.Drawing.Size(30, 38)
        Me.btn_close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btn_close.TabIndex = 4
        Me.btn_close.TabStop = False
        Me.ToolTip1.SetToolTip(Me.btn_close, "Go Back")
        Me.btn_close.Zoom = 10
        '
        'btn_refresh
        '
        Me.btn_refresh.BackColor = System.Drawing.Color.Transparent
        Me.btn_refresh.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_refresh.Image = CType(resources.GetObject("btn_refresh.Image"), System.Drawing.Image)
        Me.btn_refresh.ImageActive = CType(resources.GetObject("btn_refresh.ImageActive"), System.Drawing.Image)
        Me.btn_refresh.Location = New System.Drawing.Point(126, 6)
        Me.btn_refresh.Name = "btn_refresh"
        Me.btn_refresh.Size = New System.Drawing.Size(27, 26)
        Me.btn_refresh.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btn_refresh.TabIndex = 5
        Me.btn_refresh.TabStop = False
        Me.ToolTip1.SetToolTip(Me.btn_refresh, "Refresh")
        Me.btn_refresh.Zoom = 10
        '
        'pnl_header
        '
        Me.pnl_header.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.pnl_header.Controls.Add(Me.Panel3)
        Me.pnl_header.Controls.Add(Me.btn_close)
        Me.pnl_header.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnl_header.Location = New System.Drawing.Point(0, 0)
        Me.pnl_header.Name = "pnl_header"
        Me.pnl_header.Size = New System.Drawing.Size(719, 38)
        Me.pnl_header.TabIndex = 6
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.btn_refresh)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel3.Location = New System.Drawing.Point(556, 0)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(163, 38)
        Me.Panel3.TabIndex = 1
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.DGV_READ)
        Me.GroupBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox1.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.GroupBox1.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.GroupBox1.Location = New System.Drawing.Point(0, 38)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(719, 389)
        Me.GroupBox1.TabIndex = 8
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "My Blood Pressure Book"
        '
        'DGV_READ
        '
        Me.DGV_READ.AllowUserToAddRows = False
        Me.DGV_READ.AllowUserToDeleteRows = False
        Me.DGV_READ.AllowUserToOrderColumns = True
        Me.DGV_READ.AllowUserToResizeColumns = False
        Me.DGV_READ.AllowUserToResizeRows = False
        Me.DGV_READ.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.DGV_READ.BackgroundColor = System.Drawing.Color.White
        Me.DGV_READ.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DGV_READ.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.DGV_READ.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGV_READ.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DGV_READ.Location = New System.Drawing.Point(3, 21)
        Me.DGV_READ.MultiSelect = False
        Me.DGV_READ.Name = "DGV_READ"
        Me.DGV_READ.ReadOnly = True
        Me.DGV_READ.RowHeadersVisible = False
        Me.DGV_READ.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DGV_READ.Size = New System.Drawing.Size(713, 365)
        Me.DGV_READ.TabIndex = 0
        '
        'frm_old_read
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(719, 485)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.pnl_header)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frm_old_read"
        Me.ShowIcon = False
        Me.Text = "frm_old_read"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        CType(Me.btn_close, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btn_refresh, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnl_header.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.DGV_READ, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel2 As Panel
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents btn_delete As MaterialSkin.Controls.MaterialFlatButton
    Friend WithEvents BunifuSeparator1 As Bunifu.Framework.UI.BunifuSeparator
    Friend WithEvents Panel1 As Panel
    Friend WithEvents btn_close As Bunifu.Framework.UI.BunifuImageButton
    Friend WithEvents pnl_header As Panel
    Friend WithEvents btn_refresh As Bunifu.Framework.UI.BunifuImageButton
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents DGV_READ As DataGridView
    Friend WithEvents Panel3 As Panel
    Friend WithEvents MaterialFlatButton1 As MaterialSkin.Controls.MaterialFlatButton
End Class
