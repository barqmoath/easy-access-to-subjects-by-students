﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_main))
        Me.pnl_header = New System.Windows.Forms.Panel()
        Me.lbl_username = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lbl_time = New System.Windows.Forms.Label()
        Me.btn_menu_toogle = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btn_close = New Bunifu.Framework.UI.BunifuImageButton()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.DragControl = New Bunifu.Framework.UI.BunifuDragControl(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.BunifuElipse1 = New Bunifu.Framework.UI.BunifuElipse(Me.components)
        Me.pnl_main = New System.Windows.Forms.Panel()
        Me.pnl_show = New System.Windows.Forms.Panel()
        Me.lbl_start = New System.Windows.Forms.Label()
        Me.pnl_menu = New System.Windows.Forms.Panel()
        Me.BunifuThinButton23 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton21 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton25 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.BunifuThinButton22 = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.btn_new_read = New Bunifu.Framework.UI.BunifuThinButton2()
        Me.PictureBox_Usr = New System.Windows.Forms.PictureBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.pnl_header.SuspendLayout()
        CType(Me.btn_close, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.pnl_main.SuspendLayout()
        Me.pnl_show.SuspendLayout()
        Me.pnl_menu.SuspendLayout()
        CType(Me.PictureBox_Usr, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pnl_header
        '
        Me.pnl_header.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.pnl_header.Controls.Add(Me.lbl_username)
        Me.pnl_header.Controls.Add(Me.Label2)
        Me.pnl_header.Controls.Add(Me.lbl_time)
        Me.pnl_header.Controls.Add(Me.btn_menu_toogle)
        Me.pnl_header.Controls.Add(Me.Label1)
        Me.pnl_header.Controls.Add(Me.btn_close)
        Me.pnl_header.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnl_header.Location = New System.Drawing.Point(0, 0)
        Me.pnl_header.Name = "pnl_header"
        Me.pnl_header.Size = New System.Drawing.Size(965, 70)
        Me.pnl_header.TabIndex = 0
        '
        'lbl_username
        '
        Me.lbl_username.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.lbl_username.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl_username.Location = New System.Drawing.Point(682, 40)
        Me.lbl_username.Name = "lbl_username"
        Me.lbl_username.Size = New System.Drawing.Size(124, 23)
        Me.lbl_username.TabIndex = 7
        Me.lbl_username.Text = "User Fullname"
        Me.lbl_username.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(812, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(16, 23)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "|"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lbl_time
        '
        Me.lbl_time.Font = New System.Drawing.Font("Segoe UI", 10.0!)
        Me.lbl_time.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lbl_time.Location = New System.Drawing.Point(834, 40)
        Me.lbl_time.Name = "lbl_time"
        Me.lbl_time.Size = New System.Drawing.Size(124, 23)
        Me.lbl_time.TabIndex = 0
        Me.lbl_time.Text = "00 : 00 : 00"
        Me.lbl_time.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_menu_toogle
        '
        Me.btn_menu_toogle.BackColor = System.Drawing.Color.Transparent
        Me.btn_menu_toogle.BackgroundImage = CType(resources.GetObject("btn_menu_toogle.BackgroundImage"), System.Drawing.Image)
        Me.btn_menu_toogle.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btn_menu_toogle.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_menu_toogle.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.btn_menu_toogle.FlatAppearance.BorderSize = 0
        Me.btn_menu_toogle.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.btn_menu_toogle.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(60, Byte), Integer))
        Me.btn_menu_toogle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_menu_toogle.Location = New System.Drawing.Point(5, 23)
        Me.btn_menu_toogle.Name = "btn_menu_toogle"
        Me.btn_menu_toogle.Size = New System.Drawing.Size(36, 24)
        Me.btn_menu_toogle.TabIndex = 1
        Me.ToolTip1.SetToolTip(Me.btn_menu_toogle, "Menu Toogle")
        Me.btn_menu_toogle.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Kristen ITC", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label1.Location = New System.Drawing.Point(45, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(289, 70)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "BLOOD PRESSURE"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_close
        '
        Me.btn_close.BackColor = System.Drawing.Color.Transparent
        Me.btn_close.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_close.Image = CType(resources.GetObject("btn_close.Image"), System.Drawing.Image)
        Me.btn_close.ImageActive = CType(resources.GetObject("btn_close.ImageActive"), System.Drawing.Image)
        Me.btn_close.Location = New System.Drawing.Point(931, 6)
        Me.btn_close.Name = "btn_close"
        Me.btn_close.Size = New System.Drawing.Size(26, 25)
        Me.btn_close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.btn_close.TabIndex = 4
        Me.btn_close.TabStop = False
        Me.ToolTip1.SetToolTip(Me.btn_close, "Close ")
        Me.btn_close.Zoom = 10
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel1.Location = New System.Drawing.Point(962, 70)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(3, 488)
        Me.Panel1.TabIndex = 1
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel2.Location = New System.Drawing.Point(0, 70)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(3, 488)
        Me.Panel2.TabIndex = 2
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.Location = New System.Drawing.Point(3, 555)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(959, 3)
        Me.Panel3.TabIndex = 3
        '
        'DragControl
        '
        Me.DragControl.Fixed = True
        Me.DragControl.Horizontal = True
        Me.DragControl.TargetControl = Me.pnl_header
        Me.DragControl.Vertical = True
        '
        'BunifuElipse1
        '
        Me.BunifuElipse1.ElipseRadius = 3
        Me.BunifuElipse1.TargetControl = Me
        '
        'pnl_main
        '
        Me.pnl_main.Controls.Add(Me.pnl_show)
        Me.pnl_main.Controls.Add(Me.pnl_menu)
        Me.pnl_main.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnl_main.Location = New System.Drawing.Point(3, 70)
        Me.pnl_main.Name = "pnl_main"
        Me.pnl_main.Size = New System.Drawing.Size(959, 485)
        Me.pnl_main.TabIndex = 4
        '
        'pnl_show
        '
        Me.pnl_show.Controls.Add(Me.lbl_start)
        Me.pnl_show.Dock = System.Windows.Forms.DockStyle.Fill
        Me.pnl_show.Location = New System.Drawing.Point(240, 0)
        Me.pnl_show.Name = "pnl_show"
        Me.pnl_show.Size = New System.Drawing.Size(719, 485)
        Me.pnl_show.TabIndex = 1
        '
        'lbl_start
        '
        Me.lbl_start.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbl_start.Font = New System.Drawing.Font("Segoe UI", 38.0!, System.Drawing.FontStyle.Italic)
        Me.lbl_start.ForeColor = System.Drawing.SystemColors.GrayText
        Me.lbl_start.Location = New System.Drawing.Point(0, 0)
        Me.lbl_start.Name = "lbl_start"
        Me.lbl_start.Size = New System.Drawing.Size(719, 485)
        Me.lbl_start.TabIndex = 0
        Me.lbl_start.Text = "SELECT OPTION" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " FROM MENU TO START"
        Me.lbl_start.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'pnl_menu
        '
        Me.pnl_menu.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.pnl_menu.Controls.Add(Me.BunifuThinButton23)
        Me.pnl_menu.Controls.Add(Me.BunifuThinButton21)
        Me.pnl_menu.Controls.Add(Me.BunifuThinButton25)
        Me.pnl_menu.Controls.Add(Me.BunifuThinButton22)
        Me.pnl_menu.Controls.Add(Me.btn_new_read)
        Me.pnl_menu.Controls.Add(Me.PictureBox_Usr)
        Me.pnl_menu.Dock = System.Windows.Forms.DockStyle.Left
        Me.pnl_menu.Location = New System.Drawing.Point(0, 0)
        Me.pnl_menu.Name = "pnl_menu"
        Me.pnl_menu.Size = New System.Drawing.Size(240, 485)
        Me.pnl_menu.TabIndex = 0
        '
        'BunifuThinButton23
        '
        Me.BunifuThinButton23.ActiveBorderThickness = 1
        Me.BunifuThinButton23.ActiveCornerRadius = 7
        Me.BunifuThinButton23.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(126, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.BunifuThinButton23.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton23.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(126, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.BunifuThinButton23.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.BunifuThinButton23.BackgroundImage = CType(resources.GetObject("BunifuThinButton23.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton23.ButtonText = "WHY I USE THIS"
        Me.BunifuThinButton23.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton23.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BunifuThinButton23.ForeColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton23.IdleBorderThickness = 1
        Me.BunifuThinButton23.IdleCornerRadius = 7
        Me.BunifuThinButton23.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.BunifuThinButton23.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuThinButton23.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuThinButton23.Location = New System.Drawing.Point(16, 285)
        Me.BunifuThinButton23.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuThinButton23.Name = "BunifuThinButton23"
        Me.BunifuThinButton23.Size = New System.Drawing.Size(208, 44)
        Me.BunifuThinButton23.TabIndex = 7
        Me.BunifuThinButton23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton21
        '
        Me.BunifuThinButton21.ActiveBorderThickness = 1
        Me.BunifuThinButton21.ActiveCornerRadius = 7
        Me.BunifuThinButton21.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(126, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.BunifuThinButton21.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton21.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(126, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.BunifuThinButton21.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.BunifuThinButton21.BackgroundImage = CType(resources.GetObject("BunifuThinButton21.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton21.ButtonText = "HOW TO MAINTAIN MY PRESSURE"
        Me.BunifuThinButton21.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton21.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BunifuThinButton21.ForeColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton21.IdleBorderThickness = 1
        Me.BunifuThinButton21.IdleCornerRadius = 7
        Me.BunifuThinButton21.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.BunifuThinButton21.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuThinButton21.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuThinButton21.Location = New System.Drawing.Point(16, 233)
        Me.BunifuThinButton21.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuThinButton21.Name = "BunifuThinButton21"
        Me.BunifuThinButton21.Size = New System.Drawing.Size(208, 44)
        Me.BunifuThinButton21.TabIndex = 6
        Me.BunifuThinButton21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton25
        '
        Me.BunifuThinButton25.ActiveBorderThickness = 1
        Me.BunifuThinButton25.ActiveCornerRadius = 7
        Me.BunifuThinButton25.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(126, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.BunifuThinButton25.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton25.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(126, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.BunifuThinButton25.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.BunifuThinButton25.BackgroundImage = CType(resources.GetObject("BunifuThinButton25.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton25.ButtonText = "EDIT MY INFO"
        Me.BunifuThinButton25.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton25.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BunifuThinButton25.ForeColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton25.IdleBorderThickness = 1
        Me.BunifuThinButton25.IdleCornerRadius = 7
        Me.BunifuThinButton25.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.BunifuThinButton25.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuThinButton25.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuThinButton25.Location = New System.Drawing.Point(16, 432)
        Me.BunifuThinButton25.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuThinButton25.Name = "BunifuThinButton25"
        Me.BunifuThinButton25.Size = New System.Drawing.Size(208, 44)
        Me.BunifuThinButton25.TabIndex = 5
        Me.BunifuThinButton25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BunifuThinButton22
        '
        Me.BunifuThinButton22.ActiveBorderThickness = 1
        Me.BunifuThinButton22.ActiveCornerRadius = 7
        Me.BunifuThinButton22.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(126, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.BunifuThinButton22.ActiveForecolor = System.Drawing.Color.White
        Me.BunifuThinButton22.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(126, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.BunifuThinButton22.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.BunifuThinButton22.BackgroundImage = CType(resources.GetObject("BunifuThinButton22.BackgroundImage"), System.Drawing.Image)
        Me.BunifuThinButton22.ButtonText = "MY PRESSURE ARCHIVE"
        Me.BunifuThinButton22.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BunifuThinButton22.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BunifuThinButton22.ForeColor = System.Drawing.Color.SeaGreen
        Me.BunifuThinButton22.IdleBorderThickness = 1
        Me.BunifuThinButton22.IdleCornerRadius = 7
        Me.BunifuThinButton22.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.BunifuThinButton22.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuThinButton22.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.BunifuThinButton22.Location = New System.Drawing.Point(16, 181)
        Me.BunifuThinButton22.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.BunifuThinButton22.Name = "BunifuThinButton22"
        Me.BunifuThinButton22.Size = New System.Drawing.Size(208, 44)
        Me.BunifuThinButton22.TabIndex = 2
        Me.BunifuThinButton22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btn_new_read
        '
        Me.btn_new_read.ActiveBorderThickness = 1
        Me.btn_new_read.ActiveCornerRadius = 7
        Me.btn_new_read.ActiveFillColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(126, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.btn_new_read.ActiveForecolor = System.Drawing.Color.White
        Me.btn_new_read.ActiveLineColor = System.Drawing.Color.FromArgb(CType(CType(166, Byte), Integer), CType(CType(126, Byte), Integer), CType(CType(140, Byte), Integer))
        Me.btn_new_read.BackColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.btn_new_read.BackgroundImage = CType(resources.GetObject("btn_new_read.BackgroundImage"), System.Drawing.Image)
        Me.btn_new_read.ButtonText = "NEW ANALYS"
        Me.btn_new_read.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn_new_read.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.btn_new_read.ForeColor = System.Drawing.Color.SeaGreen
        Me.btn_new_read.IdleBorderThickness = 1
        Me.btn_new_read.IdleCornerRadius = 7
        Me.btn_new_read.IdleFillColor = System.Drawing.Color.FromArgb(CType(CType(214, Byte), Integer), CType(CType(48, Byte), Integer), CType(CType(49, Byte), Integer))
        Me.btn_new_read.IdleForecolor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_new_read.IdleLineColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.btn_new_read.Location = New System.Drawing.Point(16, 131)
        Me.btn_new_read.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btn_new_read.Name = "btn_new_read"
        Me.btn_new_read.Size = New System.Drawing.Size(208, 44)
        Me.btn_new_read.TabIndex = 1
        Me.btn_new_read.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'PictureBox_Usr
        '
        Me.PictureBox_Usr.Dock = System.Windows.Forms.DockStyle.Top
        Me.PictureBox_Usr.Image = CType(resources.GetObject("PictureBox_Usr.Image"), System.Drawing.Image)
        Me.PictureBox_Usr.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox_Usr.Name = "PictureBox_Usr"
        Me.PictureBox_Usr.Size = New System.Drawing.Size(240, 125)
        Me.PictureBox_Usr.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox_Usr.TabIndex = 0
        Me.PictureBox_Usr.TabStop = False
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'frm_main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(965, 558)
        Me.Controls.Add(Me.pnl_main)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.pnl_header)
        Me.Font = New System.Drawing.Font("Segoe UI", 8.25!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frm_main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "frm_main"
        Me.pnl_header.ResumeLayout(False)
        CType(Me.btn_close, System.ComponentModel.ISupportInitialize).EndInit()
        Me.pnl_main.ResumeLayout(False)
        Me.pnl_show.ResumeLayout(False)
        Me.pnl_menu.ResumeLayout(False)
        CType(Me.PictureBox_Usr, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents pnl_header As Panel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents Label1 As Label
    Friend WithEvents btn_close As Bunifu.Framework.UI.BunifuImageButton
    Friend WithEvents DragControl As Bunifu.Framework.UI.BunifuDragControl
    Friend WithEvents BunifuElipse1 As Bunifu.Framework.UI.BunifuElipse
    Friend WithEvents btn_menu_toogle As Button
    Friend WithEvents pnl_main As Panel
    Friend WithEvents pnl_menu As Panel
    Friend WithEvents PictureBox_Usr As PictureBox
    Friend WithEvents BunifuThinButton25 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton22 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents btn_new_read As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents pnl_show As Panel
    Friend WithEvents lbl_username As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lbl_time As Label
    Friend WithEvents Timer1 As Timer
    Public WithEvents lbl_start As Label
    Friend WithEvents BunifuThinButton21 As Bunifu.Framework.UI.BunifuThinButton2
    Friend WithEvents BunifuThinButton23 As Bunifu.Framework.UI.BunifuThinButton2
End Class
