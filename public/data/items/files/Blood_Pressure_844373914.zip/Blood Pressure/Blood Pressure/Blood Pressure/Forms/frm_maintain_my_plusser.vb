﻿Public Class frm_maintain_my_plusser
    Private Sub btn_close_Click(sender As Object, e As EventArgs) Handles btn_close.Click
        Me.Close()
        frm_main.lbl_start.Show()
        frm_main.show_state = ""
    End Sub
End Class