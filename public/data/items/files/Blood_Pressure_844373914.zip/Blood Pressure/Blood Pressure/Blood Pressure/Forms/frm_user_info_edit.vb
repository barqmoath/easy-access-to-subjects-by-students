﻿Public Class frm_user_info_edit
    Private Sub frm_user_info_edit_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For i As Integer = 1 To 200
            Me.ComboBox2.Items.Add(i)
        Next

        Me.TextBox1.Text = My.Settings.username
        Me.ComboBox1.Text = My.Settings.user_gender
        Me.ComboBox2.Text = My.Settings.user_age
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        My.Settings.username = Me.TextBox1.Text
        My.Settings.user_gender = Me.ComboBox1.Text
        My.Settings.user_age = Me.ComboBox2.Text
        Me.Close()
    End Sub
End Class